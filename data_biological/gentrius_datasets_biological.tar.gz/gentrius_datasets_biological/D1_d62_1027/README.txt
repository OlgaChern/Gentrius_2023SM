# Infer ML tree:
$FULL_PATH/iqtree-2.2.2.4-Linux/bin/iqtree2 -nt 48 -Q $f/d62_1027.nex -m MFP --seqtype AA


# Gentrius:
iqtree2 --gentrius d62_1027.ML.treefile -pr_ab_matrix d62_1027.pr_ab_matrix -pre d62_1027.gentrius
