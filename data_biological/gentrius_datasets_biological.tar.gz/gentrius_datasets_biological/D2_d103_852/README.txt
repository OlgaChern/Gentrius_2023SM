# Infer ML tree:
$FULL_PATH/iqtree-2.2.2.4-Linux/bin/iqtree2 -nt 48 -Q $f/d103_852.nex -m MFP

# Gentrius:
iqtree2 --gentrius d103_852.ML.treefile -pr_ab_matrix d103_852.pr_ab_matrix -pre d103_852.gentrius
